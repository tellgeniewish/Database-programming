package lab3;

public class DeptNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;

	public DeptNotFoundException() {
		super();
	}

	public DeptNotFoundException(String arg0) {
		super(arg0);
	}
}
