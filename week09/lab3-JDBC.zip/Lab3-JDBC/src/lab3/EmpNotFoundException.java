package lab3;

public class EmpNotFoundException extends Exception {
    private static final long serialVersionUID = 1L;

    public EmpNotFoundException() {
        super();
    }

    public EmpNotFoundException(String arg0) {
        super(arg0);
    }
}
