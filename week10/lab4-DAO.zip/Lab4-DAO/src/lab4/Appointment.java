package lab4;

public class Appointment {

}
