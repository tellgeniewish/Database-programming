package lab4;

public class Employee {
    // 필드: 사번, 이름, 직무, 입사일, 월급, 수당, 소속부서명 
    // default 생성자와, 위 필드들에 대한 getter & setter method 정의
    // 위 필드들을 초기화하는 생성자를 정의해서 활용 가능 
    // 모든 필드 값들을 출력하기 위한 toString() 정의 (Source > Generate toString() 메뉴 이용)

}
