# UserMan3
Sample project for DBP class
based on MVC architecture
- adding community functionalities

### UserMan3b branch
- branched from *master*
- using *Bootstrap* library (<https://getbootstrap.com/>)

__master branch로부터 변경된 파일__
 
- /WEB-INF/navbar.jsp <span style="color:blue">- Bootstrap Navbar, Dropdowns 이용</span>
- /WEB-INF/user/*.jsp <span style="color:blue">- Bootstrap CSS 이용</span>
- /WEB-INF/community/*.jsp <span style="color:blue">- Bootstrap CSS 이용</span>
- /css/* <span style="color:blue">- 기존 CSS 삭제</span>
